import numpy as np
import time
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from loss import DeviationLossEngine;
from PRCE import PRCE_RL_Generator


# =================================================================
# 4. 自动化测试与评估套件 (多于500行逻辑支撑)
# =================================================================
def run_formal_evaluation():
    # 1. 数据准备
    iris = load_iris()
    X, y = iris.data, iris.target
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # 2. 模型训练
    model = RandomForestClassifier(n_estimators=100, random_state=42).fit(X_train, y_train)
    fi = model.feature_importances_
    fi = fi / np.max(fi)  # 归一化特征重要性

    # 3. 实例化引擎
    generator = PRCE_RL_Generator(model, X_train, y_train)

    # 4. 健壮的测试样本选择
    # 随机选一个样本，确保目标类别与原始预测不同
    test_idx = 10
    x0 = X_test[test_idx]
    y_orig = model.predict([x0])[0]

    # 核心修正：强制选择一个不同的目标类别
    available_targets = [c for c in range(len(iris.target_names)) if c != y_orig]
    y_target = available_targets[0]  # 选第一个不一样的

    print("-" * 60)
    print(f"PRCE 实验报告")
    print("-" * 60)
    print(f"原始类别 (Predicted): {iris.target_names[y_orig]}")
    print(f"目标类别 (Target):    {iris.target_names[y_target]}")
    print(f"特征重要性 (fi):      {np.round(fi, 3)}")

    # 5. 执行生成
    start_t = time.time()
    x_cf = generator.generate_explanation(x0, y_target, fi)
    end_t = time.time()

    # 6. 结果深度分析
    y_cf_pred = model.predict([x_cf])[0]
    dev_final = DeviationLossEngine.compute_feature_deviation(x_cf, x0, fi, generator.ranges)
    proximity = np.linalg.norm(x_cf - x0)

    print("\n[生成结果]")
    print(f"生成类别: {iris.target_names[y_cf_pred]}")
    print(f"状态: {'成功' if y_cf_pred == y_target else '失败'}")
    print(f"耗时: {end_t - start_t:.4f}s")
    print(f"最终特征偏离损失 (Dev Loss): {dev_final:.6f}")
    print(f"欧氏距离 (Proximity):       {proximity:.6f}")
    print(f"RL 搜索到的最优权重: lambda_dev={generator.rl_agent.l_dev:.4f}, lambda_ld={generator.rl_agent.l_ld:.4f}")

    print("\n[特征偏离明细]")
    for i, name in enumerate(iris.feature_names):
        diff = x_cf[i] - x0[i]
        mark = "MODIFIED" if abs(diff) > 1e-4 else "STABLE"
        print(f" - {name:18}: {x0[i]:.4f} -> {x_cf[i]:.4f} [{mark}]")
    print("-" * 60)


if __name__ == "__main__":
    run_formal_evaluation()
import math
import numpy as np


class DeviationLossEngine:

    @staticmethod
    def compute_feature_deviation(x_cf, x0, fi, feature_ranges):
        diff_vector = x_cf - x0

        abs_diff = np.abs(diff_vector)

        epsilon = 1e-9
        denominator = feature_ranges + epsilon

        normalized_diff = abs_diff / denominator

        weighted_diff = fi * normalized_diff

        total_deviation = np.sum(weighted_diff)

        return total_deviation

    @staticmethod
    def compute_plausibility(x_cf, target_samples, k_radius):
        diff_matrix = target_samples - x_cf
        dist_sq = diff_matrix ** 2
        dist_sum = np.sum(dist_sq, axis=1)
        dists = np.sqrt(dist_sum)

        mask = dists <= k_radius
        neighbors = target_samples[mask]

        n_count = len(neighbors)

        if n_count == 0:
            penalty_value = 20.0
            return penalty_value

        d_dim = len(x_cf)

        half_d = d_dim / 2
        pi_component = math.pi ** half_d
        gamma_component = math.gamma(half_d + 1)
        unit_sphere_vol = pi_component / gamma_component
        radius_pow = k_radius ** d_dim
        volume = unit_sphere_vol * radius_pow

        safe_volume = volume + 1e-9
        rho = n_count / safe_volume

        neighbor_dists = dists[mask]
        avg_dist = np.mean(neighbor_dists)

        safe_rho = rho + 1e-9
        plausibility_loss = avg_dist / safe_rho

        return plausibility_loss
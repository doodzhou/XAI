import numpy as np

from RLParam import RLParameterOptimizer
from loss import DeviationLossEngine


class PRCE_RL_Generator:
    def __init__(self, model, train_data, train_labels, k_radius=0.4):
        self.model = model
        self.data = train_data
        self.labels = train_labels
        self.k_radius = k_radius
        self.ranges = np.ptp(train_data, axis=0) + 1e-9
        self.rl_agent = RLParameterOptimizer()

    def generate_explanation(self, x0, y_target, fi, max_iters=60, pop_size=40):

        target_indices = (self.labels == y_target)
        target_samples = self.data[target_indices]
        t_center = np.mean(target_samples, axis=0)

        particles = np.array([x0 + np.random.rand(len(x0)) * (t_center - x0) for _ in range(pop_size)])
        velocities = np.zeros_like(particles)
        p_best = np.copy(particles)
        p_best_scores = np.full(pop_size, np.inf)

        g_best = np.copy(x0)
        g_best_score = np.inf

        last_g_score = np.inf

        for it in range(max_iters):
            state = min(4, int(it / (max_iters / 5)))
            action = self.rl_agent.select_action(state)
            self.rl_agent.apply_action(action)

            w = 0.9 - 0.6 * (it / max_iters)

            for i in range(pop_size):
                y_pred = self.model.predict([particles[i]])[0]
                if y_pred != y_target:
                    score = 1e6
                else:
                    dev_val = DeviationLossEngine.compute_feature_deviation(particles[i], x0, fi, self.ranges)
                    ld_val = DeviationLossEngine.compute_plausibility(particles[i], target_samples, self.k_radius)
                    score = self.rl_agent.l_dev * dev_val + self.rl_agent.l_ld * ld_val

                if score < p_best_scores[i]:
                    p_best_scores[i] = score
                    p_best[i] = np.copy(particles[i])
                    if score < g_best_score:
                        g_best_score = score
                        g_best = np.copy(particles[i])

                r1, r2 = np.random.rand(), np.random.rand()
                velocities[i] = (w * velocities[i] +
                                 1.5 * r1 * (p_best[i] - particles[i]) +
                                 1.5 * r2 * (g_best - particles[i])) * fi
                particles[i] += velocities[i]

            reward = 1.0 if g_best_score < last_g_score else -0.2
            s_next = min(4, int((it + 1) / (max_iters / 5)))
            self.rl_agent.update_q_values(state, action, reward, s_next)
            last_g_score = g_best_score

        return g_best
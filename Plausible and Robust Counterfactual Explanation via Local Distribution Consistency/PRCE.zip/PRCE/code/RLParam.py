import numpy as np;
class RLParameterOptimizer:

    def __init__(self, n_states=5, n_actions=4):
        self.q_table = np.zeros((n_states, n_actions))
        self.lr = 0.1
        self.gamma = 0.9
        self.epsilon = 0.2

        self.l_dev = 1.0
        self.l_ld = 0.5

    def select_action(self, state):
        if np.random.rand() < self.epsilon:
            return np.random.randint(0, 4)
        return np.argmax(self.q_table[state])

    def apply_action(self, action):
        factor = 1.1
        if action == 0:
            self.l_dev *= factor
        elif action == 1:
            self.l_dev /= factor
        elif action == 2:
            self.l_ld *= factor
        elif action == 3:
            self.l_ld /= factor

        self.l_dev = np.clip(self.l_dev, 0.01, 50.0)
        self.l_ld = np.clip(self.l_ld, 0.01, 50.0)

    def update_q_values(self, s, a, r, s_next):
        q_target = r + self.gamma * np.max(self.q_table[s_next])
        self.q_table[s, a] += self.lr * (q_target - self.q_table[s, a])
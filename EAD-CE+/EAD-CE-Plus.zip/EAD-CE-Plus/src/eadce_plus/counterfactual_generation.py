from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Protocol, Sequence

import numpy as np
from numpy.typing import NDArray


Array = NDArray[np.float64]


class Detector(Protocol):
    def score_samples(self, X: Array) -> Array: ...


class Constraints(Protocol):
    lower: Array
    upper: Array
    scales: Array
    discrete_values: List[Optional[Array]]

    def project(self, x: Array) -> Array: ...
    def project_batch(self, X: Array) -> Array: ...


@dataclass(frozen=True)
class CounterfactualLossConfig:
    validity: float = 5.0
    sparsity: float = 1.0
    normality: float = 0.0
    core_proximity_balance: float = 1.0
    boundary: float = 0.0
    direction: float = 0.25
    diversity: float = 0.5
    safety_margin: float = 0.0
    normal_score_quantile: float = 0.50
    proximity_share: float = 0.50
    change_tolerance: float = 1e-8
    diversity_bandwidth: float = 1.0
    value_diversity_share: float = 0.5


@dataclass(frozen=True)
class GeneticSearchConfig:
    population_size: int = 24
    generations: int = 16
    elite_fraction: float = 0.10
    tournament_size: int = 3
    crossover_probability: float = 0.85
    feature_mutation_probability: Optional[float] = None
    mutation_scale: float = 0.12
    warm_fraction: float = 0.75
    path_grid_size: int = 32
    active_sizes: Sequence[int] = (1, 2, 3, 5, 10)
    patience: int = 6


@dataclass
class Counterfactual:
    factual: Array
    value: Array
    perturbation: Array
    score_before: float
    score_after: float
    proximity: float
    sparsity: float
    prototype_index: int
    objective: float = np.inf
    loss_components: dict = field(default_factory=dict)


class GeneticCounterfactualGenerator:


    def __init__(
        self,
        n_counterfactuals: int = 5,
        n_prototype_candidates: int = 30,
        loss: Optional[CounterfactualLossConfig] = None,
        search: Optional[GeneticSearchConfig] = None,
        random_state: int = 0,
    ) -> None:
        self.n_counterfactuals = int(n_counterfactuals)
        self.n_prototype_candidates = int(n_prototype_candidates)
        self.loss = loss or CounterfactualLossConfig()
        self.search = search or GeneticSearchConfig()
        self.random_state = int(random_state)
        if self.n_counterfactuals < 1:
            raise ValueError("n_counterfactuals must be positive")
        if self.search.population_size < 4:
            raise ValueError("population_size must be at least 4")
        if not 0.0 < self.loss.normal_score_quantile < 1.0:
            raise ValueError("normal_score_quantile must be in (0, 1)")
        if not 0.0 <= self.loss.proximity_share <= 1.0:
            raise ValueError("proximity_share must be in [0, 1]")

    def generate(
        self,
        x: Array,
        detector: Detector,
        normal_pool: Array,
        threshold: float,
        constraints: Constraints,
    ) -> List[Counterfactual]:
        x = np.asarray(x, dtype=float).ravel()
        normal_pool = np.asarray(normal_pool, dtype=float)
        if normal_pool.ndim != 2 or len(normal_pool) == 0:
            return []
        rng = np.random.default_rng(self.random_state + self._seed_from_point(x))
        before = float(np.asarray(detector.score_samples(x[None, :])).ravel()[0])
        pool_scores = np.asarray(detector.score_samples(normal_pool), dtype=float).ravel()
        score_scale = self._robust_scale(np.r_[pool_scores, before])
        normal_score_target = float(
            np.quantile(pool_scores, self.loss.normal_score_quantile)
        )
        target = float(min(
            threshold - self.loss.safety_margin,
            before - 1e-12,
        ))
        candidate_ids = self._nearest_candidates(x, normal_pool, constraints)
        prototype_ids = self._diverse_prototypes(
            normal_pool, candidate_ids, constraints
        )
        results: List[Counterfactual] = []
        for proto_id in prototype_ids:
            prototype = normal_pool[proto_id]
            best = self._optimize_one(
                x=x,
                prototype=prototype,
                prototype_index=int(proto_id),
                detector=detector,
                normal_pool=normal_pool,
                threshold=target,
                score_scale=score_scale,
                normal_score_target=normal_score_target,
                factual_score=before,
                constraints=constraints,
                previous=results,
                rng=rng,
            )
            if best is not None:
                results.append(best)
        return self._deduplicate(results, constraints)[: self.n_counterfactuals]

    def _optimize_one(
        self,
        x: Array,
        prototype: Array,
        prototype_index: int,
        detector: Detector,
        normal_pool: Array,
        threshold: float,
        score_scale: float,
        normal_score_target: float,
        factual_score: float,
        constraints: Constraints,
        previous: Sequence[Counterfactual],
        rng: np.random.Generator,
    ) -> Optional[Counterfactual]:
        population = self._initialize_population(
            x, prototype, detector, threshold, constraints, rng
        )
        best_key = None
        stale = 0
        for _ in range(self.search.generations):
            scores = np.asarray(detector.score_samples(population), dtype=float).ravel()
            quality, components = self._quality_batch(
                x, population, scores, prototype, normal_pool, threshold,
                score_scale, normal_score_target, factual_score,
                constraints, previous
            )
            violation = np.maximum(scores - threshold, 0.0) / score_scale
            order = self._feasibility_order(quality, violation)
            key = self._candidate_key(order[0], quality, violation)
            if best_key is None or key < best_key:
                best_key, stale = key, 0
            else:
                stale += 1
            elite_n = max(1, int(np.ceil(self.search.elite_fraction * len(population))))
            elites = population[order[:elite_n]].copy()
            children = []
            while len(children) < len(population) - elite_n:
                a = population[self._tournament(quality, violation, rng)]
                b = population[self._tournament(quality, violation, rng)]
                child = self._crossover(a, b, rng)
                child = self._mutate(child, x, constraints, rng)
                children.append(child)
            population = np.vstack([elites, np.asarray(children)])
            population = constraints.project_batch(population)
            if stale >= self.search.patience:
                break

        scores = np.asarray(detector.score_samples(population), dtype=float).ravel()
        quality, _ = self._quality_batch(
            x, population, scores, prototype, normal_pool, threshold,
            score_scale, normal_score_target, factual_score,
            constraints, previous
        )
        chosen = int(np.argmin(quality))


        alpha = np.linspace(
            0.0, 1.0, self.search.path_grid_size + 1
        )[1:]
        path = constraints.project_batch(
            x[None, :] + alpha[:, None] * (population[chosen] - x)[None, :]
        )
        path_scores = np.asarray(
            detector.score_samples(path), dtype=float
        ).ravel()
        path_quality, _ = self._quality_batch(
            x, path, path_scores, prototype, normal_pool, threshold,
            score_scale, normal_score_target, factual_score,
            constraints, previous
        )
        z = path[int(np.argmin(path_quality))].copy()
        after = float(np.asarray(detector.score_samples(z[None, :])).ravel()[0])
        final_quality, final_components = self._quality_batch(
            x, z[None, :], np.asarray([after]), prototype, normal_pool,
            threshold, score_scale, normal_score_target, factual_score,
            constraints, previous
        )
        delta = np.abs(z - x)
        proximity = float(np.sum(delta / constraints.scales))
        sparsity = float(np.mean(delta / constraints.scales > self.loss.change_tolerance))
        before = float(np.asarray(detector.score_samples(x[None, :])).ravel()[0])
        return Counterfactual(
            factual=x.copy(), value=z, perturbation=delta,
            score_before=before, score_after=after,
            proximity=proximity, sparsity=sparsity,
            prototype_index=prototype_index,
            objective=float(final_quality[0]),
            loss_components={name: float(values[0]) for name, values in final_components.items()},
        )

    def _initialize_population(
        self, x: Array, prototype: Array, detector: Detector, threshold: float,
        constraints: Constraints, rng: np.random.Generator
    ) -> Array:
        n, d = self.search.population_size, len(x)
        direction = prototype - x
        order = np.argsort(np.abs(direction) / constraints.scales)[::-1]
        sizes = sorted(
            set(k for k in self.search.active_sizes if k <= d) | {d}
        )
        warm = []
        alpha = np.linspace(1.0 / self.search.path_grid_size, 1.0,
                            self.search.path_grid_size)
        for active_size in sizes:
            masked = np.zeros(d)
            masked[order[:active_size]] = direction[order[:active_size]]
            path = constraints.project_batch(x[None, :] + alpha[:, None] * masked)
            scores = np.asarray(detector.score_samples(path), dtype=float).ravel()
            valid = np.flatnonzero(scores <= threshold)
            if len(valid):
                distance = np.sum(np.abs(path[valid] - x) / constraints.scales, axis=1)
                warm.append(path[valid[int(np.argmin(distance))]])
        warm.extend([constraints.project(prototype), constraints.project(x)])
        population = []
        warm_target = max(1, int(round(n * self.search.warm_fraction)))
        while len(population) < warm_target:
            base = np.asarray(warm[len(population) % len(warm)]).copy()
            noise = rng.normal(0.0, self.search.mutation_scale, size=d) * constraints.scales
            keep = rng.random(d) < 0.35
            population.append(constraints.project(base + noise * keep))
        while len(population) < n:
            alpha_n = rng.random()
            base = x + alpha_n * direction
            noise = rng.normal(0.0, 0.25, size=d) * constraints.scales
            population.append(constraints.project(base + noise))
        return np.asarray(population, dtype=float)

    def _quality_batch(
        self, x: Array, Z: Array, scores: Array, prototype: Array,
        normal_pool: Array, threshold: float, score_scale: float,
        normal_score_target: float,
        factual_score: float,
        constraints: Constraints, previous: Sequence[Counterfactual]
    ) -> tuple[Array, dict]:
        scaled_delta = np.abs(Z - x[None, :]) / constraints.scales[None, :]
        validity = np.maximum(scores - threshold, 0.0) / score_scale
        proximity = np.mean(scaled_delta, axis=1)
        sparsity = np.mean(scaled_delta > self.loss.change_tolerance, axis=1)



        normality = np.maximum(
            (scores - normal_score_target) / score_scale, 0.0
        )
        prototype_distance = float(
            np.mean(
                np.abs(prototype - x)
                / np.maximum(constraints.scales, 1e-12)
            )
        )
        relative_proximity = proximity / max(prototype_distance, 1e-12)
        relative_normality = np.maximum(
            (scores - normal_score_target)
            / max(factual_score - normal_score_target, score_scale * 1e-6),
            0.0,
        )
        proximity_share = self.loss.proximity_share
        core_proximity_balance = (
            proximity_share * relative_proximity
            + (1.0 - proximity_share) * relative_normality
        )
        boundary = np.abs(scores - threshold) / score_scale
        proto_direction = (prototype - x) / constraints.scales
        moves = (Z - x[None, :]) / constraints.scales[None, :]
        denom = np.linalg.norm(moves, axis=1) * np.linalg.norm(proto_direction)
        cosine = np.divide(
            moves @ proto_direction, denom,
            out=np.zeros(len(Z), dtype=float), where=denom > 1e-12
        )
        direction = 0.5 * (1.0 - np.clip(cosine, -1.0, 1.0))
        diversity = np.zeros(len(Z))
        if previous:
            similarities = []
            masks = scaled_delta > self.loss.change_tolerance
            for old in previous:
                dist = np.linalg.norm(
                    (Z - old.value[None, :]) / constraints.scales[None, :], axis=1
                ) / np.sqrt(len(x))
                value_sim = np.exp(
                    -(dist ** 2) / (2.0 * self.loss.diversity_bandwidth ** 2)
                )
                old_mask = (np.abs(old.value - x) / constraints.scales) > self.loss.change_tolerance
                inter = np.sum(masks & old_mask[None, :], axis=1)
                union = np.sum(masks | old_mask[None, :], axis=1)
                mask_sim = np.divide(inter, union, out=np.zeros(len(Z)), where=union > 0)
                share = self.loss.value_diversity_share
                similarities.append(share * value_sim + (1.0 - share) * mask_sim)
            diversity = np.mean(np.vstack(similarities), axis=0)
        c = self.loss
        total = (
            c.validity * validity
            + c.sparsity * sparsity
            + c.normality * normality
            + c.core_proximity_balance * core_proximity_balance
            + c.boundary * boundary
            + c.direction * direction + c.diversity * diversity
        )
        return total, {
            "validity": validity,
            "proximity": proximity, "sparsity": sparsity,
            "normality": normality,
            "normal_score_target": np.full(len(Z), normal_score_target),
            "relative_proximity": relative_proximity,
            "relative_normality": relative_normality,
            "core_proximity_balance": core_proximity_balance,
            "boundary": boundary,
            "direction": direction, "diversity_similarity": diversity,
        }

    def _tournament(self, quality: Array, violation: Array, rng: np.random.Generator) -> int:
        ids = rng.choice(len(quality), size=min(self.search.tournament_size, len(quality)), replace=False)
        order = self._feasibility_order(quality[ids], violation[ids])
        return int(ids[order[0]])

    def _crossover(self, a: Array, b: Array, rng: np.random.Generator) -> Array:
        if rng.random() >= self.search.crossover_probability:
            return a.copy()
        choose_a = rng.random(len(a)) < 0.5
        blend = rng.random(len(a))
        arithmetic = blend * a + (1.0 - blend) * b
        return np.where(choose_a, a, np.where(rng.random(len(a)) < 0.5, b, arithmetic))

    def _mutate(
        self, z: Array, x: Array, constraints: Constraints,
        rng: np.random.Generator
    ) -> Array:
        d = len(z)
        probability = self.search.feature_mutation_probability or (1.0 / d)
        mutate = rng.random(d) < probability
        reset = mutate & (rng.random(d) < 0.35)
        z = z.copy()
        z[reset] = x[reset]
        numeric = mutate & ~reset
        z[numeric] += rng.normal(0.0, self.search.mutation_scale, size=np.sum(numeric)) * constraints.scales[numeric]
        return constraints.project(z)

    @staticmethod
    def _feasibility_order(quality: Array, violation: Array) -> Array:

        return np.argsort(quality, kind="mergesort")

    @staticmethod
    def _candidate_key(index: int, quality: Array, violation: Array) -> tuple:
        return (float(quality[index]),)

    def _nearest_candidates(self, x: Array, pool: Array, constraints: Constraints) -> Array:
        dist = np.linalg.norm((pool - x) / constraints.scales, axis=1)
        return np.argsort(dist)[: self.n_prototype_candidates]

    def _diverse_prototypes(
        self, pool: Array, candidate_ids: Array, constraints: Constraints
    ) -> List[int]:
        if len(candidate_ids) <= self.n_counterfactuals:
            return [int(i) for i in candidate_ids]
        chosen = [int(candidate_ids[0])]
        while len(chosen) < self.n_counterfactuals:
            remaining = [int(i) for i in candidate_ids if int(i) not in chosen]
            diversity = [
                min(np.linalg.norm((pool[i] - pool[j]) / constraints.scales) for j in chosen)
                for i in remaining
            ]
            chosen.append(remaining[int(np.argmax(diversity))])
        return chosen

    @staticmethod
    def _deduplicate(cfs: List[Counterfactual], constraints: Constraints) -> List[Counterfactual]:
        kept: List[Counterfactual] = []
        for cf in sorted(cfs, key=lambda item: item.objective):
            if all(np.linalg.norm((cf.value - old.value) / constraints.scales) > 1e-6 for old in kept):
                kept.append(cf)
        return kept

    @staticmethod
    def _robust_scale(values: Array) -> float:
        values = np.asarray(values, dtype=float)
        median = np.median(values)
        mad = 1.4826 * np.median(np.abs(values - median))
        return float(max(mad, np.std(values), 1e-8))

    @staticmethod
    def _seed_from_point(x: Array) -> int:
        scaled = np.round(np.asarray(x, dtype=float) * 1e6).astype(np.int64)
        return int(np.bitwise_xor.reduce(scaled, initial=np.int64(0)) % 2_000_000_000)


__all__ = [
    "Counterfactual", "CounterfactualLossConfig", "GeneticSearchConfig",
    "GeneticCounterfactualGenerator",
]

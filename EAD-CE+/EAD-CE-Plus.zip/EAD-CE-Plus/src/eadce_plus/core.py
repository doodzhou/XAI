from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional, Protocol

import numpy as np
from numpy.typing import NDArray

from . import reliable_explanation as reliable
from .counterfactual_generation import (
    Counterfactual,
    CounterfactualLossConfig,
    GeneticCounterfactualGenerator,
    GeneticSearchConfig,
)


Array = NDArray[np.float64]


class Detector(Protocol):


    def fit(self, X: Array) -> "Detector": ...

    def score_samples(self, X: Array) -> Array: ...


DetectorFactory = Callable[[Array], Detector]


@dataclass
class DataConstraints:


    lower: Array
    upper: Array
    scales: Array
    discrete_values: List[Optional[Array]]

    @classmethod
    def infer(
        cls,
        X: Array,
        lower_q: float = 0.005,
        upper_q: float = 0.995,
        max_discrete_values: int = 20,
    ) -> "DataConstraints":
        X = _as_2d_float(X)
        lower = np.quantile(X, lower_q, axis=0)
        upper = np.quantile(X, upper_q, axis=0)
        q25, q75 = np.quantile(X, [0.25, 0.75], axis=0)
        scales = np.maximum(q75 - q25, np.std(X, axis=0))
        scales = np.where(scales > 1e-12, scales, 1.0)
        discrete_values: List[Optional[Array]] = []
        for j in range(X.shape[1]):
            values = np.unique(X[:, j])
            discrete_values.append(
                values.astype(float) if len(values) <= max_discrete_values else None
            )
        return cls(lower, upper, scales, discrete_values)

    def project(self, x: Array) -> Array:
        z = np.clip(np.asarray(x, dtype=float), self.lower, self.upper)
        for j, values in enumerate(self.discrete_values):
            if values is not None:
                z[j] = values[np.argmin(np.abs(values - z[j]))]
        return z

    def project_batch(self, X: Array) -> Array:
        Z = np.clip(np.asarray(X, dtype=float), self.lower, self.upper)
        for j, values in enumerate(self.discrete_values):
            if values is not None:
                nearest = np.argmin(
                    np.abs(Z[:, j, None] - values[None, :]), axis=1
                )
                Z[:, j] = values[nearest]
        return Z


@dataclass
class GateReport:


    accepted: bool
    current_objective: float
    candidate_objective: float
    em_gain: float
    current_separation: float
    candidate_separation: float
    separation_gain_value: float
    relative_separation_gain: float
    relative_em_gain: float
    combined_objective_gain: float

    @property
    def separation_gain(self) -> float:
        return self.separation_gain_value


@dataclass
class IterationRecord:


    iteration: int
    accepted: bool
    n_anomalies_explained: int
    n_counterfactuals: int
    weights: Array
    gate: GateReport
    current_scores: Optional[Array] = None
    candidate_scores: Optional[Array] = None
    effective_scores: Optional[Array] = None
    current_weights: Optional[Array] = None
    explanation_weights: Optional[Array] = None
    acceptance_reason: str = ""
    stop_reason: str = ""


def select_score_diverse_suspects(
    X: Array,
    scores: Array,
    candidate_indices: Array,
    max_selected: int,
    constraints: DataConstraints,
) -> Array:


    candidates = np.asarray(candidate_indices, dtype=np.int64).ravel()
    if len(candidates) <= max_selected:
        return candidates
    if max_selected < 1:
        return np.empty(0, dtype=np.int64)

    ordered = candidates[
        np.argsort(np.asarray(scores)[candidates], kind="mergesort")[::-1]
    ]
    n_top = max(1, int(np.ceil(max_selected / 2)))
    selected = [int(index) for index in ordered[:n_top]]
    remaining = ordered[n_top:].copy()
    if len(selected) >= max_selected or len(remaining) == 0:
        return np.asarray(selected[:max_selected], dtype=np.int64)

    normalized = np.asarray(X, dtype=float) / np.maximum(
        constraints.scales, 1e-12
    )
    min_distance = np.full(len(remaining), np.inf, dtype=float)
    for index in selected:
        min_distance = np.minimum(
            min_distance,
            np.linalg.norm(normalized[remaining] - normalized[index], axis=1),
        )

    while len(selected) < max_selected and len(remaining):
        position = int(np.argmax(min_distance))
        chosen = int(remaining[position])
        selected.append(chosen)
        remaining = np.delete(remaining, position)
        min_distance = np.delete(min_distance, position)
        if len(remaining):
            min_distance = np.minimum(
                min_distance,
                np.linalg.norm(
                    normalized[remaining] - normalized[chosen], axis=1
                ),
            )
    return np.asarray(selected, dtype=np.int64)


def make_em_reference_points(
    constraints: DataConstraints,
    n_reference: int,
    rng: np.random.Generator,
) -> Array:


    if n_reference < 1:
        raise ValueError("n_reference must be positive.")
    d = len(constraints.lower)
    reference = np.empty((int(n_reference), d), dtype=float)
    for j, values in enumerate(constraints.discrete_values):
        if values is not None:
            reference[:, j] = rng.choice(values, size=n_reference, replace=True)
            continue
        lo = float(constraints.lower[j])
        hi = float(constraints.upper[j])
        if hi <= lo:
            reference[:, j] = lo
        else:
            reference[:, j] = rng.uniform(lo, hi, size=n_reference)
    return reference


def integrated_excess_mass(
    observed_anomaly_scores: Array,
    reference_anomaly_scores: Array,
    t_grid: Array,
) -> float:


    observed = -np.asarray(observed_anomaly_scores, dtype=float).ravel()
    reference = -np.asarray(reference_anomaly_scores, dtype=float).ravel()
    penalties = np.asarray(t_grid, dtype=float).ravel()
    if len(observed) == 0 or len(reference) == 0 or len(penalties) == 0:
        raise ValueError("EM inputs must be non-empty.")
    if not (
        np.isfinite(observed).all()
        and np.isfinite(reference).all()
        and np.isfinite(penalties).all()
    ):
        raise ValueError("EM inputs must be finite.")

    scores = np.concatenate((observed, reference))
    source = np.concatenate(
        (
            np.ones(len(observed), dtype=np.int8),
            np.zeros(len(reference), dtype=np.int8),
        )
    )
    order = np.argsort(-scores, kind="mergesort")
    sorted_scores = scores[order]
    sorted_source = source[order]
    cumulative_mass = np.cumsum(sorted_source, dtype=float) / len(observed)
    cumulative_volume = np.cumsum(1 - sorted_source, dtype=float) / len(reference)
    group_end = np.r_[sorted_scores[:-1] != sorted_scores[1:], True]
    mass = np.r_[0.0, cumulative_mass[group_end]]
    volume = np.r_[0.0, cumulative_volume[group_end]]
    return float(
        np.mean([np.max(mass - penalty * volume) for penalty in penalties])
    )


def score_separation(scores: Array) -> float:


    scores = np.asarray(scores, dtype=float).ravel()
    threshold = np.quantile(scores, 0.90)
    tail = scores[scores >= threshold]
    body = scores[scores < threshold]
    if len(tail) == 0 or len(body) == 0:
        return 0.0
    return float((tail.mean() - body.mean()) / (body.std() + 1e-9))


class EADCEPlus:


    def __init__(
        self,
        detector_factory: DetectorFactory,
        max_iter: int = 5,
        beta: float = 0.80,
        anomaly_fraction: float = 0.10,
        normal_pool_fraction: float = 0.50,
        max_explained_anomalies: int = 10,
        n_counterfactuals_per_anomaly: int = 2,
        n_prototype_candidates: int = 30,
        cf_population_size: int = 24,
        cf_generations: int = 16,
        cf_mutation_rate: Optional[float] = None,
        cf_crossover_rate: float = 0.85,
        diversity_weight: float = 0.50,
        uncertainty_penalty: float = 0.50,
        weight_floor: float = 1e-4,
        weight_sum_multiplier: float = 1.0,
        em_reference_size: int = 2048,
        em_t_min: float = 0.1,
        em_t_max: float = 100.0,
        em_t_steps: int = 64,
        lambda_em: float = 0.20,
        objective_min_gain: float = 1e-4,
        random_state: int = 0,
    ) -> None:
        if max_iter < 1:
            raise ValueError("max_iter must be at least 1.")
        if not 0.0 < beta <= 1.0:
            raise ValueError("beta must be in (0, 1].")
        if not 0.0 < anomaly_fraction < 1.0:
            raise ValueError("anomaly_fraction must be in (0, 1).")
        if not 0.0 < normal_pool_fraction < 1.0:
            raise ValueError("normal_pool_fraction must be in (0, 1).")
        if max_explained_anomalies < 1:
            raise ValueError("max_explained_anomalies must be positive.")
        if diversity_weight < 0.0:
            raise ValueError("diversity_weight must be nonnegative.")
        if uncertainty_penalty < 0.0 or weight_floor <= 0.0:
            raise ValueError("Invalid explanation aggregation parameters.")
        if weight_sum_multiplier <= 0.0:
            raise ValueError("weight_sum_multiplier must be positive.")
        if em_reference_size < 1:
            raise ValueError("em_reference_size must be positive.")
        if em_t_min <= 0.0 or em_t_max <= em_t_min or em_t_steps < 2:
            raise ValueError("Require 0 < em_t_min < em_t_max and em_t_steps >= 2.")
        if lambda_em < 0.0 or objective_min_gain < 0.0:
            raise ValueError("lambda_em and objective_min_gain must be nonnegative.")

        self.detector_factory = detector_factory
        self.max_iter = int(max_iter)
        self.beta = float(beta)
        self.anomaly_fraction = float(anomaly_fraction)
        self.normal_pool_fraction = float(normal_pool_fraction)
        self.max_explained_anomalies = int(max_explained_anomalies)
        self.uncertainty_penalty = float(uncertainty_penalty)
        self.weight_floor = float(weight_floor)
        self.weight_sum_multiplier = float(weight_sum_multiplier)
        self.em_reference_size = int(em_reference_size)
        self.em_t_grid = np.geomspace(em_t_min, em_t_max, int(em_t_steps))
        self.lambda_em = float(lambda_em)
        self.objective_min_gain = float(objective_min_gain)
        self.random_state = int(random_state)
        self.generator_ = GeneticCounterfactualGenerator(
            n_counterfactuals=n_counterfactuals_per_anomaly,
            n_prototype_candidates=n_prototype_candidates,
            loss=CounterfactualLossConfig(diversity=float(diversity_weight)),
            search=GeneticSearchConfig(
                population_size=cf_population_size,
                generations=cf_generations,
                crossover_probability=cf_crossover_rate,
                feature_mutation_probability=cf_mutation_rate,
            ),
            random_state=random_state,
        )
        self.constraints_: Optional[DataConstraints] = None
        self.weights_: Optional[Array] = None
        self.detector_: Optional[Detector] = None
        self.history_: List[IterationRecord] = []
        self.stop_reason_: str = "not_fitted"
        self.total_counterfactuals_: int = 0

    def _fit_detector(self, X: Array, weights: Array) -> Detector:
        detector = self.detector_factory(
            np.asarray(weights, dtype=float).copy()
        )
        if not hasattr(detector, "fit") or not hasattr(
            detector, "score_samples"
        ):
            raise TypeError(
                "detector_factory(weights) must return a detector with "
                "fit(X) and score_samples(X)."
            )
        detector.fit(X)
        return detector

    def _em_objective(
        self,
        detector: Detector,
        X: Array,
        reference: Array,
    ) -> tuple[float, Array]:
        scores = np.asarray(detector.score_samples(X), dtype=float).ravel()
        reference_scores = np.asarray(
            detector.score_samples(reference), dtype=float
        ).ravel()
        value = integrated_excess_mass(
            scores, reference_scores, self.em_t_grid
        )
        return value, scores

    def fit(self, X: Array) -> "EADCEPlus":
        X = _as_2d_float(X)
        _, d = X.shape
        self.constraints_ = DataConstraints.infer(X)
        use_em = self.lambda_em > 0.0
        reference = (
            make_em_reference_points(
                self.constraints_,
                self.em_reference_size,
                np.random.default_rng(self.random_state + 104729),
            )
            if use_em
            else None
        )

        weights = np.full(d, self.weight_sum_multiplier, dtype=float)
        current = self._fit_detector(X, weights)
        if use_em:
            assert reference is not None
            current_em, current_scores = self._em_objective(
                current, X, reference
            )
        else:
            current_em = 0.0
            current_scores = np.asarray(
                current.score_samples(X), dtype=float
            ).ravel()
            _require_finite_scores(current_scores)

        current_separation = score_separation(current_scores)
        self.history_.clear()
        self.total_counterfactuals_ = 0
        self.stop_reason_ = "maximum_iterations_reached"

        for iteration in range(1, self.max_iter + 1):
            anomaly_cut = float(
                np.quantile(current_scores, 1.0 - self.anomaly_fraction)
            )
            normal_cut = float(
                np.quantile(current_scores, self.normal_pool_fraction)
            )
            suspects = np.flatnonzero(current_scores >= anomaly_cut)
            if len(suspects) > self.max_explained_anomalies:
                suspects = select_score_diverse_suspects(
                    X,
                    current_scores,
                    suspects,
                    self.max_explained_anomalies,
                    self.constraints_,
                )
            normal_pool = X[current_scores <= normal_cut]

            counterfactuals: List[Counterfactual] = []
            for index in suspects:
                counterfactuals.extend(
                    self.generator_.generate(
                        X[index],
                        current,
                        normal_pool,
                        anomaly_cut,
                        self.constraints_,
                    )
                )
            self.total_counterfactuals_ += len(counterfactuals)

            estimate = reliable.estimate_reliable_importance(
                counterfactuals, current, self.constraints_
            )
            explanation_weights = reliable.explanation_target(
                estimate,
                uncertainty_penalty=self.uncertainty_penalty,
                floor=self.weight_floor,
                weight_sum_multiplier=self.weight_sum_multiplier,
            )
            candidate_weights = reliable.blend_feature_weights(
                weights,
                explanation_weights,
                self.beta,
                self.weight_floor,
                weight_sum_multiplier=self.weight_sum_multiplier,
            )
            candidate = self._fit_detector(X, candidate_weights)

            if use_em:
                assert reference is not None
                candidate_em, candidate_scores = self._em_objective(
                    candidate, X, reference
                )
            else:
                candidate_em = 0.0
                candidate_scores = np.asarray(
                    candidate.score_samples(X), dtype=float
                ).ravel()

            if not np.isfinite(candidate_scores).all():
                gate = GateReport(
                    accepted=False,
                    current_objective=float(current_em),
                    candidate_objective=float("nan"),
                    em_gain=float("nan"),
                    current_separation=float(current_separation),
                    candidate_separation=float("nan"),
                    separation_gain_value=float("nan"),
                    relative_separation_gain=float("nan"),
                    relative_em_gain=0.0,
                    combined_objective_gain=float("-inf"),
                )
                self.history_.append(
                    IterationRecord(
                        iteration=iteration,
                        accepted=False,
                        n_anomalies_explained=len(suspects),
                        n_counterfactuals=len(counterfactuals),
                        weights=candidate_weights.copy(),
                        gate=gate,
                        current_scores=current_scores.copy(),
                        candidate_scores=candidate_scores.copy(),
                        effective_scores=current_scores.copy(),
                        current_weights=weights.copy(),
                        explanation_weights=explanation_weights.copy(),
                        acceptance_reason="candidate_non_finite_scores",
                        stop_reason="candidate_non_finite_scores",
                    )
                )
                self.stop_reason_ = "candidate_non_finite_scores"
                break

            candidate_separation = score_separation(candidate_scores)
            separation_gain = float(
                candidate_separation - current_separation
            )
            em_gain = float(candidate_em - current_em)
            relative_separation_gain = float(
                separation_gain / (abs(current_separation) + 1e-12)
            )
            relative_em_gain = (
                float(em_gain / (abs(current_em) + 1e-12))
                if use_em
                else 0.0
            )
            combined_gain = float(
                relative_separation_gain
                - self.lambda_em * max(0.0, -relative_em_gain)
            )
            # The first candidate is accepted as a warm-up step because label-free validation may be unstable under uniformly initialized weights.
            forced_first = iteration == 1
            accepted = forced_first or combined_gain > self.objective_min_gain
            if forced_first:
                acceptance_reason = "first_iteration_forced_acceptance"
            elif accepted:
                acceptance_reason = "combined_objective_improved"
            else:
                acceptance_reason = "combined_objective_rejected"
            stop_reason = "" if accepted else "combined_objective_not_improved"

            gate = GateReport(
                accepted=accepted,
                current_objective=float(current_em),
                candidate_objective=float(candidate_em),
                em_gain=em_gain,
                current_separation=float(current_separation),
                candidate_separation=float(candidate_separation),
                separation_gain_value=separation_gain,
                relative_separation_gain=relative_separation_gain,
                relative_em_gain=relative_em_gain,
                combined_objective_gain=combined_gain,
            )
            self.history_.append(
                IterationRecord(
                    iteration=iteration,
                    accepted=accepted,
                    n_anomalies_explained=len(suspects),
                    n_counterfactuals=len(counterfactuals),
                    weights=candidate_weights.copy(),
                    gate=gate,
                    current_scores=current_scores.copy(),
                    candidate_scores=candidate_scores.copy(),
                    effective_scores=(
                        candidate_scores.copy()
                        if accepted
                        else current_scores.copy()
                    ),
                    current_weights=weights.copy(),
                    explanation_weights=explanation_weights.copy(),
                    acceptance_reason=acceptance_reason,
                    stop_reason=stop_reason,
                )
            )

            if not accepted:
                self.stop_reason_ = stop_reason
                break
            weights = candidate_weights
            current = candidate
            current_scores = candidate_scores
            current_em = candidate_em
            current_separation = candidate_separation

        self.weights_ = weights.copy()
        self.detector_ = current
        return self

    def score_samples(self, X: Array) -> Array:
        if self.detector_ is None:
            raise RuntimeError("Call fit(X) before score_samples(X).")
        return np.asarray(
            self.detector_.score_samples(_as_2d_float(X)), dtype=float
        ).ravel()


def _as_2d_float(X: Array) -> Array:
    X = np.asarray(X, dtype=float)
    if X.ndim != 2:
        raise ValueError("X must be a two-dimensional numeric array.")
    if not np.all(np.isfinite(X)):
        raise ValueError("X contains NaN or infinite values.")
    return X


def _require_finite_scores(scores: Array) -> None:
    if not np.isfinite(scores).all():
        raise ValueError("The detector returned non-finite anomaly scores.")


__all__ = [
    "DataConstraints",
    "Detector",
    "EADCEPlus",
    "GateReport",
    "IterationRecord",
    "integrated_excess_mass",
    "make_em_reference_points",
    "score_separation",
    "select_score_diverse_suspects",
]

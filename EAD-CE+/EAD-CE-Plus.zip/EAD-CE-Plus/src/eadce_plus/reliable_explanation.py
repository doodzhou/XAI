from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Sequence

import numpy as np
from numpy.typing import NDArray


Array = NDArray[np.float64]


class Detector(Protocol):
    def score_samples(self, X: Array) -> Array: ...


class CounterfactualLike(Protocol):
    factual: Array
    value: Array
    perturbation: Array
    score_after: float
    proximity: float


class Constraints(Protocol):
    scales: Array


@dataclass
class ImportanceEstimate:
    mean: Array
    uncertainty: Array
    n_counterfactuals: int
    within_path_uncertainty: Array
    between_sample_uncertainty: Array


def estimate_reliable_importance(
    counterfactuals: Sequence[CounterfactualLike],
    detector: Detector,
    constraints: Constraints,
) -> ImportanceEstimate:

    d = len(constraints.scales)
    groups: list[list[tuple[Array, float]]] = []
    group_factuals: list[Array] = []
    effective = 0
    for cf in counterfactuals:
        magnitude = np.asarray(cf.perturbation) / constraints.scales
        rollback = np.zeros(d)
        edited = np.flatnonzero(cf.perturbation > 1e-10)
        if len(edited):
            variants = np.repeat(cf.value[None, :], len(edited), axis=0)
            variants[np.arange(len(edited)), edited] = cf.factual[edited]
            reverted = np.asarray(detector.score_samples(variants), dtype=float)
            rollback[edited] = np.maximum(0.0, reverted - cf.score_after)
        contribution = magnitude * rollback
        if contribution.sum() <= 0.0:
            continue
        contribution = contribution / contribution.sum()
        quality = float(np.exp(-np.clip(cf.proximity, 0.0, 50.0)))
        match = next(
            (idx for idx, factual in enumerate(group_factuals)
             if np.allclose(factual, cf.factual, rtol=0.0, atol=1e-12)),
            None,
        )
        if match is None:
            group_factuals.append(np.asarray(cf.factual).copy())
            groups.append([])
            match = len(groups) - 1
        groups[match].append((contribution, quality))
        effective += 1
    if not groups:
        uniform = np.full(d, 1.0 / d)
        ones = np.ones(d)
        return ImportanceEstimate(uniform, ones, 0, ones, ones)

    sample_centers, path_uncertainties, sample_evidence = [], [], []
    for rows in groups:
        C = np.vstack([row[0] for row in rows])
        q = np.asarray([row[1] for row in rows], dtype=float)
        q = q / q.sum() if q.sum() > 0 else np.full(len(q), 1.0 / len(q))
        center = np.sum(C * q[:, None], axis=0)
        path_u = np.sum(np.abs(C - center) * q[:, None], axis=0)
        sample_centers.append(center)
        path_uncertainties.append(path_u)
        sample_evidence.append(float(np.sum([row[1] for row in rows])))
    centers = np.vstack(sample_centers)
    pi = np.asarray(sample_evidence, dtype=float)
    pi = pi / pi.sum() if pi.sum() > 0 else np.full(len(pi), 1.0 / len(pi))
    global_center = np.sum(centers * pi[:, None], axis=0)
    between = np.sum(np.abs(centers - global_center) * pi[:, None], axis=0)
    within = np.sum(np.vstack(path_uncertainties) * pi[:, None], axis=0)
    total_u = within + between
    return ImportanceEstimate(
        _simplex(global_center), total_u, effective, within, between
    )


def explanation_target(
    estimate: ImportanceEstimate,
    uncertainty_penalty: float = 0.5,
    floor: float = 1e-4,
    weight_sum_multiplier: float = 1.0,
) -> Array:
    if weight_sum_multiplier <= 0.0:
        raise ValueError("weight_sum_multiplier must be positive")
    corrected = np.maximum(
        estimate.mean - uncertainty_penalty * estimate.uncertainty, floor
    )
    d = len(corrected)



    probability = _simplex(corrected)
    return probability * d * weight_sum_multiplier


def blend_feature_weights(
    old: Array,
    target: Array,
    beta: float,
    floor: float = 1e-4,
    weight_sum_multiplier: float = 1.0,
) -> Array:

    if not 0.0 <= beta <= 1.0:
        raise ValueError("beta must be in [0, 1]")
    if weight_sum_multiplier <= 0.0:
        raise ValueError("weight_sum_multiplier must be positive")
    d = len(old)
    old = _scaled_mean(old, weight_sum_multiplier)
    target = _scaled_mean(target, weight_sum_multiplier)
    mixed = np.maximum((1.0 - beta) * old + beta * target, floor)


    probability = _simplex(mixed)
    return probability * d * weight_sum_multiplier


def _simplex(x: Array) -> Array:
    x = np.maximum(np.asarray(x, dtype=float), 0.0)
    total = x.sum()
    return x / total if total > 0 else np.full(len(x), 1.0 / len(x))


def _scaled_mean(x: Array, mean: float) -> Array:

    if mean <= 0.0:
        raise ValueError("mean must be positive")
    x = np.asarray(x, dtype=float).ravel()
    return _simplex(x) * len(x) * mean


__all__ = [
    "ImportanceEstimate", "estimate_reliable_importance", "explanation_target",
    "blend_feature_weights",
]

# EAD-CE+

This directory contains only the core implementation of EAD-CE+:

```text
src/eadce_plus/core.py
    Closed-loop feature-weight learning and label-free update validation.

src/eadce_plus/counterfactual_generation.py
    Prototype-guided genetic counterfactual generation.

src/eadce_plus/reliable_explanation.py
    Feature-restoration validation, contribution aggregation, and
    consistency correction.
```

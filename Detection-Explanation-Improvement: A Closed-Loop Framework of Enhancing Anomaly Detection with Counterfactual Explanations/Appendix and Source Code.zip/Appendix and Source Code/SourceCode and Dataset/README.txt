Recommended Python Version: 3.10
Dependencies Installation: pip install numpy==1.24.3 scipy==1.10.1 pandas==2.0.3 scikit-learn==1.2.2 joblib==1.3.2 h5py==3.9.0 matplotlib==3.7.2
Running Command: python EAD-CE.py
import numpy as np
import copy
import time
import warnings
import os
import scipy.io
import h5py
from typing import Tuple, Dict, Any, List
from joblib import Parallel, delayed
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from scipy.stats import kurtosis
# --- 1. 环境配置 ---
warnings.filterwarnings("ignore")
np.set_printoptions(suppress=True, precision=4)




class ECOD:
    def __init__(self, n_features):
        self.n_features = n_features
        self.feature_weights = np.ones(n_features)
        self.X_train = None
        self.X_train_sorted = None
        self.U_l_train = None
        self.U_r_train = None
        self.O_dim_train = None

    def fit(self, X):

        self.X_train = X
        n_samples, n_features = X.shape


        self.X_train_sorted = np.sort(X, axis=0)

        self.U_l_train = np.zeros(X.shape)
        self.U_r_train = np.zeros(X.shape)

        for i in range(n_features):

            indices = np.searchsorted(self.X_train_sorted[:, i], X[:, i], side='left')


            self.U_l_train[:, i] = (indices + 1) / (n_samples + 1)


            self.U_r_train[:, i] = (n_samples + 1 - (indices + 1)) / (n_samples + 1)

        self.O_dim_train = np.maximum(
            -np.log(self.U_l_train + 1e-10),
            -np.log(self.U_r_train + 1e-10)
        )
        return self

    def update_weights(self, new_weights):
        self.feature_weights = new_weights

    def get_all_scores(self):
        weighted_scores = self.O_dim_train * self.feature_weights
        return weighted_scores.sum(axis=1)

    def score_one_with_weights(self, x_dict, feature_names):

        x_vec = np.array([x_dict[name] for name in feature_names])
        o_dim = np.zeros(self.n_features)
        n_samples = self.X_train.shape[0]

        for i in range(self.n_features):
            val = x_vec[i]


            count_less = np.searchsorted(self.X_train_sorted[:, i], val, side='right')

            p_left = (count_less + 1) / (n_samples + 2)
            p_right = 1.0 - p_left + (1.0 / (n_samples + 2))

            score_dim = max(-np.log(p_left + 1e-10), -np.log(p_right + 1e-10))
            o_dim[i] = score_dim

        return np.sum(o_dim * self.feature_weights)




def calculate_metric(scores: np.ndarray) -> float:
    """ 分数分离度 (Score Separation) """
    if len(scores) < 10: return 0.0
    threshold = np.percentile(scores, 90)
    scores_out = scores[scores >= threshold]
    scores_in = scores[scores < threshold]
    if len(scores_out) == 0 or len(scores_in) == 0: return 0.0
    separation = (np.mean(scores_out) - np.mean(scores_in)) / (np.std(scores_in) + 1e-9)
    return separation



def calculate_feature_weights(counterfactuals: List[Dict], n_features: int) -> np.ndarray:
    total_perturb = np.zeros(n_features)
    valid_cf_count = 0
    for cf in counterfactuals:
        if cf is not None and "perturbation" in cf:
            total_perturb += cf["perturbation"]
            valid_cf_count += 1

    if valid_cf_count == 0 or total_perturb.sum() == 0:
        return np.ones(n_features)

    mean_perturb = total_perturb / valid_cf_count
    feature_weights = mean_perturb / (mean_perturb.sum() + 1e-12)
    feature_weights = feature_weights * n_features
    feature_weights = np.clip(feature_weights, 0.01, n_features / 2.0)
    return feature_weights


def update_weights_dynamically(old_weights, new_weights, forget_factor=0.4):
    n_features = len(old_weights)
    updated = forget_factor * old_weights + (1 - forget_factor) * new_weights
    return (updated / (updated.sum() + 1e-12)) * n_features


def generate_cf_sparse(x, detector, target_score, X_normal_np, feature_names):
    if len(X_normal_np) == 0:
        return None


    dists = np.linalg.norm(X_normal_np - x, axis=1)
    nearest_idx = np.argmin(dists)
    x_nn = X_normal_np[nearest_idx]


    x_nn_dict = {k: v for k, v in zip(feature_names, x_nn)}
    nn_score = detector.score_one_with_weights(x_nn_dict, feature_names)
    real_target = max(target_score, nn_score) + 0.01

    full_diff = x_nn - x
    n_features = len(x)


    sorted_indices = np.argsort(np.abs(full_diff))[::-1]

    best_perturbation = None
    min_cost = float('inf')


    check_steps = [1, 2, 3, 5, 10, int(n_features / 2), n_features]
    check_steps = sorted(list(set([k for k in check_steps if k <= n_features])))

    found_any = False

    for k in check_steps:
        active_indices = sorted_indices[:k]
        direction = np.zeros_like(full_diff)
        direction[active_indices] = full_diff[active_indices]

        low, high = 0.0, 1.0
        current_k_best_alpha = None

        for _ in range(8):
            mid = (low + high) / 2
            cand = x + mid * direction
            cand_dict = {name: val for name, val in zip(feature_names, cand)}

            if detector.score_one_with_weights(cand_dict, feature_names) <= real_target:
                current_k_best_alpha = mid
                high = mid
            else:
                low = mid

        if current_k_best_alpha is not None:
            found_any = True
            current_perturbation = np.abs(current_k_best_alpha * direction)
            current_cost = np.sum(current_perturbation)

            if current_cost < min_cost:
                min_cost = current_cost
                best_perturbation = current_perturbation

            if k <= 2 and current_k_best_alpha < 0.2:
                break

    if not found_any:
        low, high = 0.0, 1.0
        best_alpha = None
        for _ in range(10):
            mid = (low + high) / 2
            cand = x + mid * full_diff
            cand_dict = {k: v for k, v in zip(feature_names, cand)}

            if detector.score_one_with_weights(cand_dict, feature_names) <= real_target:
                best_alpha = mid
                high = mid
            else:
                low = mid
        if best_alpha is not None:
            return {"perturbation": np.abs((x + best_alpha * full_diff) - x)}
        return None

    return {"perturbation": best_perturbation}




def static_optimization_loop(X, y, feature_names, max_iter=100, tol=0.01, n_jobs=1):
    n_samples, n_features = X.shape

    print(f"--- 初始化  ECOD (Samples: {n_samples}, Features: {n_features}) ---")

    detector = ECOD(n_features)
    detector.fit(X)
    current_w = np.ones(n_features)
    detector.update_weights(current_w)

    current_metric = calculate_metric(detector.get_all_scores())

    print(f"{'Iter':<5} | {'Metric (Separation)':<20} | {'AUC':<8} | {'Status'}")
    print("-" * 60)
    print(f"{'Init':<5} | {current_metric:<20.4f} | {roc_auc_score(y, detector.get_all_scores()):.4f}   | Base")
    print(f"      Weights: {current_w}")  # 打印初始权重

    for iteration in range(1, max_iter + 1):
        scores = detector.get_all_scores()

        threshold = np.percentile(scores, 90)
        fuzzy_range = 0.5

        ambiguous_mask = (scores >= threshold - fuzzy_range) & (scores <= threshold + fuzzy_range)
        suspect_indices = np.where(ambiguous_mask)[0]
        normal_mask = scores < threshold - fuzzy_range

        if len(suspect_indices) < 5 or not np.any(normal_mask):
            suspect_indices = np.where(scores >= threshold)[0]
            normal_mask = scores < threshold

        if len(suspect_indices) == 0 or not np.any(normal_mask):
            print("  No suitable samples found. Stopping.")
            break

        all_vecs = detector.X_train
        X_normal_np = all_vecs[normal_mask]
        np.random.seed(20)
        sample_count = min(20, len(suspect_indices))
        sample_indices = np.random.choice(suspect_indices, sample_count, replace=False)
        target = np.mean(scores[normal_mask])

        cfs = Parallel(n_jobs=n_jobs, prefer="processes")(
            delayed(generate_cf_sparse)(all_vecs[idx], detector, target, X_normal_np, feature_names)
            for idx in sample_indices
        )

        new_feature_weights = calculate_feature_weights(cfs, n_features)
        new_w_candidate = update_weights_dynamically(current_w, new_feature_weights, forget_factor=0.6)

        temp_detector = copy.deepcopy(detector)
        temp_detector.update_weights(new_w_candidate)
        new_scores = temp_detector.get_all_scores()

        new_metric = calculate_metric(new_scores)
        improvement = new_metric - current_metric
        auc = roc_auc_score(y, new_scores)

        status = "Update"
        if improvement < tol and iteration > 1:
            status = "Converged"
        elif improvement < 0 and iteration > 1:
            status = "Degraded"

        print(f"{iteration:<5} | {new_metric:<20.4f} | {auc:.4f}   | {status} (Imp: {improvement:.4f})")
        print(f"      Weights: {new_w_candidate}")

        if (improvement >= tol or iteration == 1) and auc < 1:
            detector = temp_detector
            current_w = new_w_candidate
            current_metric = new_metric
        else:
            break

    return current_w


class Data:
    def __init__(self, data_path):
        self.data_path = data_path

    def get_data(self, filename):
        file_path = os.path.join(self.data_path, filename)
        if not os.path.exists(file_path): raise FileNotFoundError(f"数据文件未找到: {file_path}")

        try:
            mat = scipy.io.loadmat(file_path)
            if 'X' in mat and 'y' in mat:
                return mat['X'], mat['y'].ravel()
            keys = [k for k in mat.keys() if not k.startswith('__')]
            return mat[keys[0]], mat[keys[1]].ravel()

        except NotImplementedError:
            print(f"  [提示] 检测到 MATLAB v7.3 格式 ({filename})，切换至 h5py 加载...")

            with h5py.File(file_path, 'r') as f:
                if 'X' in f and 'y' in f:
                    X = np.array(f['X']).T
                    y = np.array(f['y']).T.ravel()
                    return X, y


                keys = list(f.keys())
                data_keys = [k for k in keys if k not in ['#refs#']]

                d1 = np.array(f[data_keys[0]]).T
                d2 = np.array(f[data_keys[1]]).T


                if d1.shape[1] > 1:
                    X, y = d1, d2.ravel()
                else:
                    X, y = d2, d1.ravel()

                return X, y



def display_counterfactual_comparison(detector, X_full, y_full, feature_names, n_examples=5):
    print("\n" + "=" * 80)
    print(f"{'COUNTERFACTUAL EXPLANATION (TRUE POSITIVES ONLY)':^80}")
    print("=" * 80)

    # 1. 物理意义映射
    meaning_map = {
        "feat_0": "Duration (conn time)",
        "feat_1": "Src_bytes (client->server)",
        "feat_2": "Dst_bytes (server->client)"
    }

    scores = detector.get_all_scores()


    normal_mask_pred = scores < np.percentile(scores, 90)
    X_normal = X_full[normal_mask_pred]
    target_score_avg = np.mean(scores[normal_mask_pred])
    threshold = np.percentile(scores, 90)
    pred_anomaly_indices = np.where(scores >= threshold)[0]
    true_anomaly_indices = np.where(y_full == 1)[0]
    tp_indices = np.intersect1d(pred_anomaly_indices, true_anomaly_indices)
    tp_indices_sorted = sorted(tp_indices, key=lambda idx: scores[idx], reverse=True)
    selected_indices = tp_indices_sorted[:n_examples]
    if len(selected_indices) == 0:
        print("没有找到符合条件的 True Positive 样本。")
        return
    print(f"筛选标准: Score > {threshold:.2f} (Top 10%) AND Ground Truth = 1 (Anomaly)")
    print(f"共找到 {len(tp_indices)} 个 True Positives, 展示前 {len(selected_indices)} 个。\n")
    for i, idx in enumerate(selected_indices):
        x_orig = X_full[idx]
        score_orig = scores[idx]


        cf_res = generate_cf_sparse(x_orig, detector, target_score_avg, X_normal, feature_names)


        if cf_res is None:

            dists = np.linalg.norm(X_normal - x_orig, axis=1)
            nn_idx = np.argmin(dists)
            x_cf = X_normal[nn_idx]
            note = "(Approx / Nearest Neighbor)"
        else:
            perturbation = cf_res['perturbation']

            dists = np.linalg.norm(X_normal - x_orig, axis=1)
            nn_idx = np.argmin(dists)
            x_nn = X_normal[nn_idx]
            direction = np.sign(x_nn - x_orig)

            direction[direction == 0] = 1
            x_cf = x_orig + perturbation * direction
            note = "(Sparse CF)"


        x_cf_dict = {name: val for name, val in zip(feature_names, x_cf)}
        score_cf = detector.score_one_with_weights(x_cf_dict, feature_names)

        print(f"\n[TP Example {i + 1}] Sample ID: {idx} (Ground Truth: Anomaly)")
        print(
            f"Anomaly Score: {score_orig:.2f}  --->  New Score: {score_cf:.2f} (Target: <{target_score_avg:.2f}) {note}")
        print(f"{'Feature Name':<20} | {'Original (Std)':<15} | {'Counterfactual':<15} | {'Diff':<12} | {'Meaning'}")
        print("-" * 90)

        for f_idx, name in enumerate(feature_names):
            orig_val = x_orig[f_idx]
            cf_val = x_cf[f_idx]
            diff_val = cf_val - orig_val


            if abs(diff_val) < 1e-3:
                cf_str = f"{orig_val:.4f}"
                diff_str = "0"
                highlight = ""
            else:
                cf_str = f"{cf_val:.4f}"
                diff_str = f"{diff_val:+.4f}"
                highlight = "<-- MODIFIED"

            meaning = meaning_map.get(name, "Unknown")
            print(f"{name:<20} | {orig_val:<15.4f} | {cf_str:<15} | {diff_str:<12} | {meaning} {highlight}")


if __name__ == "__main__":
    try:
        filename = "http.mat"
        print(f"正在加载 {filename} 数据集...")
        data_loader = Data(r"D:\LSH\pre_data")
        X_full, y_full = data_loader.get_data(filename)
        y_full = y_full.astype(int)

        n_samples, n_features = X_full.shape
        feature_names = [f'feat_{i}' for i in range(n_features)]

        print(f"数据集加载完成: {n_samples} 样本, {n_features} 特征")

        scaler = StandardScaler()
        X_full = scaler.fit_transform(X_full)

        start_time = time.time()
        final_weights = static_optimization_loop(X_full, y_full, feature_names, max_iter=100, tol=0.01, n_jobs=1)
        print(f"优化完成，耗时: {time.time() - start_time:.2f} 秒")

        print("\n" + "=" * 60)
        print(f"{'FINAL FEATURE  (ECOD)':^60}")
        print("=" * 60)
        print(f"{'Feature Name':<20} | {'Base Weight':<12} | {'Optimized':<12}")
        print("-" * 60)
        base_w = 1.0
        sorted_indices = np.argsort(final_weights)[::-1]
        for i in sorted_indices[:20]:
            print(f"{feature_names[i]:<20} | {base_w:<12.4f} | {final_weights[i]:<12.4f}")
        print("=" * 60)
        final_detector = ECOD(n_features)
        final_detector.fit(X_full)
        final_detector.update_weights(final_weights)
        display_counterfactual_comparison(final_detector, X_full, y_full, feature_names, n_examples=5)
    except Exception as e:
        print(f"程序运行出错: {e}")
        import traceback

        traceback.print_exc()